// login.js

document.querySelector('form').addEventListener('submit', async (e) => {
    e.preventDefault();
  
    // Get user input
    const email = document.querySelector('#email').value.trim().toLowerCase();
    const password = document.querySelector('#password').value;
  
    try {
      const response = await fetch('http://localhost:3001/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
      });
  
      const result = await response.json();
  
      if (response.ok) {
        alert('✅ Login successful!');
        // Optionally store login status (if session or JWT-based login is added later)
        // localStorage.setItem('userEmail', result.email);
        window.location.href = 'dashboard.html';
      } else {
        alert(`❌ ${result.message || 'Login failed. Please check your credentials.'}`);
      }
  
    } catch (err) {
      console.error('Login error:', err);
      alert('⚠️ Failed to connect to the server. Please try again later.');
    }
  });
  