const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const cors = require('cors');

// Initialize Express app
const app = express();
app.use(cors());
app.use(bodyParser.json());

// Connect to SQLite database
const db = new sqlite3.Database('./ems.db', (err) => {
  if (err) {
    console.error('Could not connect to database', err);
  } else {
    console.log('Connected to SQLite database');
  }
});

// Create tables if not exist
db.serialize(() => {
  console.log("🚀 Running db.serialize()");
  db.run(`CREATE TABLE IF NOT EXISTS Employees (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name TEXT,
    last_name TEXT,
    department TEXT,
    role TEXT
  )`, (err) => {
    if (err) console.error("Employees table error:", err);
  });

  db.run(`CREATE TABLE IF NOT EXISTS Attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_id INTEGER,
    date TEXT,
    status TEXT,
    FOREIGN KEY (employee_id) REFERENCES Employees(id)
  )`, (err) => {
    if (err) console.error("Attendance table error:", err);
  });

  db.run(`CREATE TABLE IF NOT EXISTS Users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE,
    password TEXT
  )`, (err) => {
    if (err) console.error("Users table error:", err);
  });

  db.get("SELECT * FROM Users WHERE email = ?", ['admin@gmail.com'], (err, row) => {
    if (err) {
      console.error("Error checking default user:", err);
    } else if (!row) {
      db.run("INSERT INTO Users (email, password) VALUES (?, ?)", ['admin@gmail.com', '12345'], (err) => {
        if (err) console.error("Error inserting default admin:", err);
        else console.log('✅ Default admin user created: admin@gmail.com / 12345');
      });
    }
  });
});


// ========== ROUTES ==========

// 1. Login (from Users table)
app.post('/login', (req, res) => {
  const { email, password } = req.body;

  db.get("SELECT * FROM Users WHERE email = ?", [email], (err, user) => {
    if (err) {
      res.status(500).json({ message: "Internal server error" });
    } else if (!user || user.password !== password) {
      res.status(401).json({ message: "Invalid credentials" });
    } else {
      res.status(200).json({ message: "Login successful", email: user.email });
    }
  });
});

// 2. Create new Employee
app.post('/employees', (req, res) => {
  const { first_name, last_name, department, role } = req.body;
  const stmt = db.prepare('INSERT INTO Employees (first_name, last_name, department, role) VALUES (?, ?, ?, ?)');
  stmt.run(first_name, last_name, department, role, function (err) {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.status(201).json({ id: this.lastID, first_name, last_name, department, role });
    }
  });
});

// 3. Get single Employee by ID
app.get('/employees/:id', (req, res) => {
  const { id } = req.params;
  db.get('SELECT * FROM Employees WHERE id = ?', [id], (err, row) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else if (row) {
      res.status(200).json(row);
    } else {
      res.status(404).json({ message: 'Employee not found' });
    }
  });
});

// 4. Get all Employees
app.get('/employees', (req, res) => {
  db.all('SELECT * FROM Employees', [], (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.status(200).json(rows);
    }
  });
});

// 5. Log Attendance
app.post('/attendance', (req, res) => {
  const { employee_id, date, status } = req.body;
  const stmt = db.prepare('INSERT INTO Attendance (employee_id, date, status) VALUES (?, ?, ?)');
  stmt.run(employee_id, date, status, function (err) {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.status(201).json({ id: this.lastID, employee_id, date, status });
    }
  });
});
// 6. Get today's attendance count
app.get('/attendance/today', (req, res) => {
  const today = new Date().toISOString().split('T')[0]; // Format: YYYY-MM-DD
  db.get("SELECT COUNT(*) as count FROM Attendance WHERE date = ?", [today], (err, row) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.status(200).json({ count: row.count });
    }
  });
});
// 7. Get all attendance records
app.get('/attendance/all', (req, res) => {
  db.all("SELECT * FROM Attendance", [], (err, rows) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.status(200).json(rows);
    }
  });
});

// Start the server
const PORT = 3001;
app.listen(PORT, () => {
  console.log(`✅ Server running on http://localhost:${PORT}`);
});